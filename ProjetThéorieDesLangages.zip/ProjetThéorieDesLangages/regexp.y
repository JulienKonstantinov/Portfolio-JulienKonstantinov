%{
/*
 * Section des déclarations C :
 * Inclusion des bibliothèques nécessaires et déclarations de fonctions.
 * Les fonctions yylex() et yyerror() sont fournies par Flex/Bison.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Déclarations des fonctions générées par Flex/Bison
#if YYBISON
int yylex(); // Fonction générée par Flex pour l'analyse lexicale
int yyerror(const char *s); // Fonction pour gérer les erreurs syntaxiques
#endif
%}

/*
 * Définition de l'union YYSTYPE :
 * Permet de définir le type des valeurs sémantiques retournées par les tokens et les règles.
 * Ici, on utilise une structure pour stocker une chaîne de caractères.
 */
%union {
    struct {
        char chaine[1024]; // Chaîne pour stocker les expressions générées
    } e;
}

/*
 * Déclaration des tokens :
 * Chaque token correspond à un symbole terminal reconnu par l'analyseur lexical (Flex).
 */
%token A B C EPSILON
%token PAR_O PAR_F
%token PLUS CONCAT ETOILE_KLEENE
%token LIGNE

/*
 * Déclaration du type des non-terminaux :
 * Ici, le non-terminal 'expression' utilise la structure 'e' de l'union pour stocker une chaîne.
 */
%type <e> expression

/*
 * Déclaration des priorités et de l'associativité des opérateurs :
 * %left : Associativité à gauche (pour PLUS et CONCAT)
 * %right : Associativité à droite (pour ETOILE_KLEENE, opérateur unaire)
 * L'ordre des déclarations définit les priorités (ETOILE_KLEENE a la priorité la plus haute).
 */
%left PLUS
%left CONCAT
%right ETOILE_KLEENE

%%
/*
 * Règles de grammaire :
 * Chaque règle définit comment les tokens et non-terminaux s'assemblent.
 */

/*
 * Règle principale : 'fichier'
 * Reçoit deux expressions séparées par un LIGNE, génère un fichier Python 'main.py'
 * qui compare les deux automates générés à partir des expressions.
 */
fichier:
    expression LIGNE expression LIGNE {
        // Ouvre le fichier 'main.py' en écriture
        FILE *fp = fopen("main.py", "w");

        // Écrit le code Python pour créer et comparer les automates
        fprintf(fp, "from automate2 import *\n\n");
        fprintf(fp, "a1_final = tout_faire(%s)\n", $1.chaine); // Première expression
        fprintf(fp, "a2_final = tout_faire(%s)\n", $3.chaine); // Deuxième expression
        fprintf(fp, "\nif egal(a1_final, a2_final):\n");
        fprintf(fp, "    print(\"EGAL\")\n");
        fprintf(fp, "else:\n");
        fprintf(fp, "    print(\"NON EGAL\")\n");
        fclose(fp); // Ferme le fichier
    }
;

/*
 * Règles pour 'expression' :
 * Chaque règle construit une chaîne de caractères représentant l'expression en Python.
 */
expression:
    A { strcpy($$.chaine, "automate(\"a\")"); } // Si le token est A, crée un automate pour 'a'
    | B { strcpy($$.chaine, "automate(\"b\")"); } // Si le token est B, crée un automate pour 'b'
    | C { strcpy($$.chaine, "automate(\"c\")"); } // Si le token est C, crée un automate pour 'c'
    | EPSILON { strcpy($$.chaine, "automate(\"E\")"); } // Si le token est EPSILON, crée un automate pour epsilon
    | PAR_O expression PAR_F { $$ = $2; } // Si l'expression est entre parenthèses, retourne l'expression intérieure
    | expression ETOILE_KLEENE { sprintf($$.chaine, "etoile(%s)", $1.chaine); } // Applique l'étoile de Kleene
    | expression CONCAT expression { sprintf($$.chaine, "concatenation(%s,%s)", $1.chaine, $3.chaine); } // Concaténation de deux expressions
    | expression PLUS expression { sprintf($$.chaine, "union(%s,%s)", $1.chaine, $3.chaine); } // Union de deux expressions
;

/*
 * Section du code utilisateur :
 * Définition des fonctions yyerror() et main().
 */
%%

/*
 * Fonction yyerror :
 * Affiche un message d'erreur en cas d'erreur syntaxique.
 */
int yyerror(const char *s) {
    fprintf(stderr, "Erreur syntaxique : %s\n", s);
    return 0;
}

/*
 * Fonction main :
 * Appelle yyparse() pour démarrer l'analyse syntaxique du fichier d'entrée.
 */
int main() {
    yyparse(); // Démarre l'analyse syntaxique
    return 0;
}