# version 2: correction d'un bug dans la fonction minimisation
import copy as cp


class automate:
    """
    classe de manipulation des automates
    l'alphabet est l'ensemble des caractères alphabétiques minuscules et "E" pour epsilon, 
    et "O" pour l'automate vide
    """
    
    def __init__(self, expr="O"):
        """
        construit un automate élémentaire pour une expression régulière expr 
            réduite à un caractère de l'alphabet, ou automate vide si "O"
        identifiant des états = entier de 0 à n-1 pour automate à n états
        état initial = état 0
        """
        
        # alphabet
        self.alphabet = list("abc")
        # l'expression doit contenir un et un seul caractère de l'alphabet
        if expr not in (self.alphabet + ["O", "E"]):
            raise ValueError("l'expression doit contenir un et un seul\
                           caractère de l'alphabet " + str(self.alphabet))
        # nombre d'états
        if expr == "O":
            # langage vide
            self.n = 1
        elif expr == "E":
            self.n = 1
        else:
            self.n = 2
        # états finals: liste d'états (entiers de 0 à n-1)
        if expr == "O":
            self.final = []
        elif expr == "E":
            self.final = [0]
        else:
            self.final = [1]
        # transitions: dico indicé par (état, caractère) qui donne la liste des états d'arrivée
        self.transition =  {} if (expr in ["O", "E"]) else {(0,expr): [1]}
        # nom de l'automate: obtenu par application des règles de construction
        self.name = "" if expr == "O" else "(" + expr + ")" 
        
    def __str__(self):
        """affichage de l'automate par fonction print"""
        res = "Automate " + self.name + "\n"
        res += "Nombre d'états " + str(self.n) + "\n"
        res += "Etats finaux " + str(self.final) + "\n"
        res += "Transitions:\n"
        for k,v in self.transition.items():    
            res += str(k) + ": " + str(v) + "\n"
        res += "*********************************"
        return res
    
    def ajoute_transition(self, q0, a, qlist):
        """ ajoute la liste de transitions (q0, a, q1) pour tout q1 
            dans qlist à l'automate
            qlist est une liste d'états
        """
        if not isinstance(qlist, list): #isintance permet de vérifier si un objet est d'un type spécifique ou d'une classe donnée
            raise TypeError("Erreur de type: ajoute_transition requiert une liste à ajouter")
        if (q0, a) in self.transition:
            self.transition[(q0, a)] = self.transition[(q0, a)] + qlist
        else:
            self.transition.update({(q0, a): qlist})
    
    
def concatenation(a1, a2): 
    """Retourne l'automate qui reconnaît la concaténation des 
    langages reconnus par les automates a1 et a2"""

    a1 = cp.deepcopy(a1)
    a2 = cp.deepcopy(a2)

    a = automate() #création de l'automate qui va contenir la concaténation des automates a1 et a2 (il est vide pour l'instant)

    a.n = a1.n + a2.n #nb d'états dans l'automate crée
    nb_etats_a1 = a1.n
    for (q0, symb), qlist in a1.transition.items():
        a.ajoute_transition(q0, symb, qlist) #ajouter les transitions de a1 

    for (q0, symb), qlist in a2.transition.items():
        q_nv = q0 + nb_etats_a1 #On rajoute les états de a1 pour décaler et avoir un ordre cohérent

        qlist1 = [q + nb_etats_a1 for q in qlist]  #ajouter les transitions de a2 pour que les etats du nv automate soient cohérents
        a.ajoute_transition(q_nv, symb, qlist1)

    for f in a1.final: #ajouter transition E des états finaux de a1 vers état init de a2
        a.ajoute_transition(f, "E", [nb_etats_a1]) #[nb_etats_a1] représente ici le premier état de a2

    a.final = [f + nb_etats_a1 for f in a2.final]

    #nom de l'automate
    a.name = "(" + a1.name + "." + a2.name + ")"

    return a


def union(a1, a2): 
    """Retourne l'automate qui reconnaît l'union des 
    langages reconnus par les automates a1 et a2"""

    #Créer une copie profonde des deux automates
    a1 = cp.deepcopy(a1)
    a2 = cp.deepcopy(a2)

    #Renommer les états des deux automates pour éviter les conflits
    for transition in list(a1.transition.keys()):
        etat_depart, caractere = transition
        a1.transition[(etat_depart+1, caractere)] = [etat_arrivee+1 for etat_arrivee in a1.transition[transition]]
        del a1.transition[transition]
    a1.final = [i+1 for i in a1.final]

    for transition in list(a2.transition.keys()):
        etat_depart, caractere = transition
        a2.transition[(etat_depart+a1.n+1, caractere)] = [etat_arrivee+a1.n+1 for etat_arrivee in a2.transition[transition]]
        del a2.transition[transition]
    a2.final = [i+a1.n+1 for i in a2.final]

    #Créer un nouvel automate pour l'union
    a = automate("E")  #Automate avec un état initial epsilon
    a.name = f"({a1.name} + {a2.name})" #Mettre a jour le nom de l'automate
    a.n += a1.n+a2.n  #1 état initial + états des deux automates
    a.final = a1.final + a2.final  #États finaux fusionnés

    #Ajouter les transitions 
    a.transition.update(a1.transition)
    a.transition.update(a2.transition)
    a.transition[(0, "E")] = [1, a1.n+1]  # 1 = état initial de a1, nb_etats_a1 + 1 = état initial de a2

    return a


def etoile(a):
    """Retourne l'automate qui reconnaît l'étoile de Kleene du 
    langage reconnu par l'automate a""" 

    a = cp.deepcopy(a)
    a1 = automate()

    a1.n = a.n + 1 #nb d'états dans a1

    for (q0, symb), qlist in a.transition.items():
        q_nv = q0 + 1
        qlist1 = [q + 1 for q in qlist]
        a1.ajoute_transition(q_nv, symb, qlist1)
    
    #les états finaux de a1 sont l'état init (pour E) et les états finaux de a
    a1.final = [0] + [f + 1 for f in a.final]

    #rajouter une E transition du nouvel etat init vers l'ancien etat init
    a1.ajoute_transition(0, "E", [1])

    #pour pouvoir boucler, rajouter une transition vers l'ancien état init
    for f in a.final:
        a1.ajoute_transition(f+1, "E", [1])

    
    a1.name = "(" + a.name + ")*"

    return a1


def acces_epsilon(a):
    """ retourne la liste pour chaque état des états accessibles par epsilon
        transitions pour l'automate a
        res[i] est la liste des états accessible pour l'état i
    """
    # on initialise la liste résultat qui contient au moins l'état i pour chaque état i
    res = [[i] for i in range(a.n)]
    for i in range(a.n):
        candidats = list(range(i)) + list(range(i+1, a.n))
        new = [i]
        while True:
            # liste des epsilon voisins des états ajoutés en dernier:
            voisins_epsilon = []
            for e in new:
                if (e, "E") in a.transition.keys():
                    voisins_epsilon += [j for j in a.transition[(e, "E")]]
            # on calcule la liste des nouveaux états:
            new = list(set(voisins_epsilon) & set(candidats))
            # si la nouvelle liste est vide on arrête:
            if new == []:
                break
            # sinon on retire les nouveaux états ajoutés aux états candidats
            candidats = list(set(candidats) - set(new))
            res[i] += new 
    return res


def supression_epsilon_transitions(a):
    """ retourne l'automate équivalent sans epsilon transitions
    """
    # on copie pour éviter les effets de bord     
    a = cp.deepcopy(a)
    res = automate()
    res.name = a.name
    res.n = a.n
    res.final = a.final
    # pour chaque état on calcule les états auxquels il accède
    # par epsilon transitions.
    acces = acces_epsilon(a)
    # on retire toutes les epsilon transitions
    res.transition = {c: j for c, j in a.transition.items() if c[1] != "E"}
    for i in range(a.n):
        # on ajoute i dans les états finals si accès à un état final:
        if (set(acces[i]) & set(a.final)):
            if i not in res.final:
                res.final.append(i)
        # on ajoute les nouvelles transitions en parcourant toutes les transitions
        for c, v in a.transition.items():
            if c[1] != "E" and c[0] in acces[i]:
                res.ajoute_transition(i, c[1], v)
    return res
        
        
def determinisation(a):
    """
    Retourne l'automate déterministe équivalent
    (construction par sous-ensembles, version compatible projet)
    """
    a = cp.deepcopy(a)

    afd = automate("E")
    afd.name = f"({a.name} déterminisé)"
    afd.alphabet = a.alphabet
    afd.transition = {}
    afd.final = []

    # état initial = {0}
    etats_a_traiter = [(0,)]
    dico = {}   # mapping ensemble d'états -> numéro
    compteur = 0

    while etats_a_traiter:
        etat = etats_a_traiter.pop(0)

        # attribution d'un numéro si nouvel état
        if etat not in dico:
            dico[etat] = compteur
            compteur += 1

        # état final si au moins un état de l'ensemble est final
        if any(q in a.final for q in etat):
            if dico[etat] not in afd.final:
                afd.final.append(dico[etat])

        # calcul des transitions
        for c in a.alphabet:
            arrivee = set()

            for q in etat:
                if (q, c) in a.transition:
                    arrivee.update(a.transition[(q, c)])

            if arrivee:
                arrivee = tuple(sorted(arrivee))

                # créer l'état d'arrivée AVANT de l'utiliser
                if arrivee not in dico:
                    dico[arrivee] = compteur
                    compteur += 1
                    etats_a_traiter.append(arrivee)

                afd.transition[(dico[etat], c)] = [dico[arrivee]]

    afd.n = compteur
    return afd
    
    
def completion(a):
    """ retourne l'automate a complété
        l'automate en entrée doit être déterministe
    """
    a = cp.deepcopy(a)
    e = automate("E")
    e.name = f"({a.name} complet)"
    e.n += a.n
    e.final = a.final
    e.transition.update(a.transition)
    
    for transition in list(e.transition.keys()):
        etat_depart = transition[0]
        for i in a.alphabet:
            if (etat_depart, i) not in e.transition:
                e.transition[(etat_depart, i)] = [e.n-1]
            for j in e.final:
                if (j, i) not in e.transition:
                    e.transition[(j, i)] = [e.n-1]
            e.transition[(e.n-1,i)] = [e.n-1]
    return e 


###################################################
# version corrigée de la fonction de minimisation #
###################################################

def minimisation(a):
    """ retourne l'automate minimum
        a doit être déterministe complet
        algo par raffinement de partition (algo de Moore)
    """
    # on copie pour éviter les effets de bord     
    a = cp.deepcopy(a)
    res = automate()
    res.name = a.name
    
    # Étape 1 : partition initiale = finaux / non finaux
    part = [set(a.final), set(range(a.n)) - set(a.final)]
    # on retire les ensembles vides
    part = [e for e in part if e != set()]  
    
    # Étape 2 : raffinement jusqu’à stabilité
    modif = True
    while modif:
        modif = False
        new_part = []
        for e in part:
            # sous-ensembles à essayer de séparer
            classes = {}
            for q in e:
                # signature = tuple des indices des blocs atteints pour chaque lettre
                signature = []
                for c in a.alphabet:
                    for i, e2 in enumerate(part):
                        if a.transition[(q, c)][0] in e2:
                            signature.append(i)
                # on ajoute l'état q à la clef signature calculée
                classes.setdefault(tuple(signature), set()).add(q)
            if len(classes) > 1:
                # s'il y a >2 signatures différentes on a séparé des états dans e
                modif = True
                new_part.extend(classes.values())
            else:
                new_part.append(e)
        part = new_part
    # on réordonne la partition pour que le premier sous-ensemble soit celui qui contient l'état initial
    for i, e in enumerate(part):
        if 0 in e:
            part[0], part[i] = part[i], part[0]
            break
 
     
    # Étape 3 : on construit le nouvel automate minimal
    mapping = {}
    # on associe à chaque état q le nouvel état i
    # obtenu comme étant l'indice du sous-ensemble de part
    for i, e in enumerate(part):
        for q in e:
            mapping[q] = i

    res.n = len(part)
    res.final = list({mapping[q] for q in a.final if q in mapping})
    for i, e in enumerate(part):
        # on récupère un élément de e:
        representant = next(iter(e))
        for c in a.alphabet:
            q = a.transition[(representant, c)][0]
            res.transition[(i, c)] = [mapping[q]]
    return res
    

def tout_faire(a):
    a1 = supression_epsilon_transitions(a)
    a2 = determinisation(a1)
    a3 = completion(a2)
    a4 = minimisation(a3)
    return a4


def egal(a1, a2):
    """ retourne True si a1 et a2 sont isomorphes
        a1 et a2 doivent être minimaux
    """
    vus = set() # vus est un ensemble pour les paires qu'on a deja traite, pour ne pas boucler (pas de doublons autorisé dans les ensembles)

    def compare(q1, q2):
        if (q1,q2) in vus:
            return True #si on a déjà visité ce couple on sait que c ok
        vus.add((q1,q2))

        if (q1 in a1.final) != (q2 in a2.final):
            return False #vérifier que les états finaux sont compatibles
        
        for i in a1.alphabet: #on teste toutes les lettres
            q1_suiv = a1.transition[(q1, i)][0] #[0] sert à récupérer l'unique état de destination car l'automate est deterministe.
            q2_suiv = a2.transition[(q2, i)][0]

            if compare(q1_suiv, q2_suiv) == False:
                return False
        
        return True

    return compare(0,0)



# TESTS
if __name__ == "__main__":

    print("Test 1 : automates de base")
    a = automate("a")
    b = automate("b")
    print(a)
    print(b)

    print("Test 2 : union")
    u1 = union(a, b)              # a + b
    u2 = union(a, a)              # a + a
    u3 = union(a, union(b, a))    # a + (b + a)

    print(u1)
    print(u2)
    print(u3)

    print("Test 3 : concaténation")
    c1 = concatenation(a, union(b, a))   # a.(b + a)
    c2 = concatenation(union(a, b), a)   # (a + b).a

    print(c1)
    print(c2)

    print("Test 4 : étoile de Kleene")
    e1 = etoile(union(a, b))       # (a + b)*
    e2 = etoile(etoile(a))         # (a*)*

    print(e1)
    print(e2)

    print("Test 5 : déterminisation")
    sans_e1 = supression_epsilon_transitions(u1)
    sans_e2 = supression_epsilon_transitions(e1)
    d1 = determinisation(sans_e1)
    d2 = determinisation(sans_e2)

    print(d1)
    print(d2)

    print("Test 6 : complétion")
    comp1 = completion(d1)
    comp2 = completion(d2)

    print(comp1)
    print(comp2)

    print("Test 7 : égalité")
    print("a + a == a :", egal(tout_faire(u2), tout_faire(a)))

    e1 = concatenation(etoile(union(a, b)), a)   # (a + b)*a
    e2 = concatenation(a, etoile(union(a, b)))   # a(a + b)*

    print("(a + b)*a == a(a + b)* :", egal(tout_faire(e1), tout_faire(e2)))
