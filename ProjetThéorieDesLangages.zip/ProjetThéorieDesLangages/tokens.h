
#ifndef TOKENS_H // Vérifie si TOKENS_H n'est pas défini
#define TOKENS_H // Définit TOKENS_H pour éviter les inclusions multiples

#define A 1
#define B 2
#define C 3

#define EPSILON 4

#define PLUS 10  // +
#define CONCAT 11   // .
#define ETOILE_KLEENE 12  // *

#define PAR_O 101  // (
#define PAR_F 102  // )

#endif