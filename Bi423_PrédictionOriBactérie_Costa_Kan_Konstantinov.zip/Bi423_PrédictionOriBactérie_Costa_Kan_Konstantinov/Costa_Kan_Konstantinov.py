
###IMPORTS###

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import pandas as pd
import tkinter as tk
from tkinter import ttk


###FONCTIONS PRINCIPALES####

def read_file(filename):
    """Fonction permettant d'extraire le texte d'un fichier FASTA."""
    f = open(filename, 'r')
    seq = ""
    line = f.readline() #Premier readline pour ne pas ajouter la première ligne du fichier FASTA
    line = f.readline()
    #On ajoute toutes les autres lignes à notre séquence
    while line!="":
        seq = seq + line
        line = f.readline()
    f.close()
    #On enlève les retour à la ligne et on met la séquence en majuscule
    seq = seq.replace('\n', "")
    seq = seq.upper()
    return seq 


def clear():
    """Fonction permettant de tout supprimer sur une fenêtre Tkinter, à part trois labels pour entrer le chemin du fichier, la taille de la fenêtre, et la boîte DnaA."""
    #On supprime les entrées, les labels, les canvas, les textes, les frames, les scrollbars, et les treeviews
    for widget in root.winfo_children():
        if isinstance(widget, tk.Entry):
            widget.delete(0, tk.END)
        elif isinstance(widget, tk.Label):
            widget.config(text="")
        elif isinstance(widget, tk.Canvas):
            widget.destroy()
        elif isinstance(widget, tk.Text):
            widget.delete(1.0, tk.END)
        elif isinstance(widget, tk.Frame):
            widget.destroy()
        elif isinstance(widget, tk.Scrollbar):
            widget.destroy()
        elif isinstance(widget, ttk.Treeview):
            widget.destroy()
    #On remet les labels concernant le chemin du ficher, la taille de la fenêtre, et la boîte DnaA
    label_file.config(text="Entrez le chemin du fichier :")
    label_window.config(text="Entrez la taille de la fenêtre :")
    label_box.config(text="Entrez la boîte DnaA :")
    return


def window_check(seq, window):
    """Fonction permettant d'afficher la séquence si la taille de la fenêtre est correcte, et d'afficher un message d'erreur sinon."""
    #Si la taille de la fenêtre n'est pas comprise entre 1 et la taille de la séquence, on affiche un message d'erreur
    if window<=0 or window>len(seq):
        label_check.config(text="Taille de la fenêtre incorrecte, cette dernière doit être entre 1 et "+str(len(seq)))
    #Sinon, on affiche la séquence sous forme de frame déroulable avec une scrollbar
    else:
        label_check.config(text="Taille de la fenêtre correcte") #Label affichant un message de confirmation
        label_seq = tk.Label(root, text="Votre séquence de " + str(len(seq)) + " nucléotides : ") #Label affichant la taille de notre séquence
        label_seq.place(x=800, y=10)
        frame_seq = tk.Frame(root, width=700, height=300)
        frame_seq.place(x=790, y=40) 
        text_seq = tk.Text(frame_seq, wrap="word")
        text_seq.place(x=10, y=10, width=600, height=200)
        scrollbar_seq = tk.Scrollbar(frame_seq, command=text_seq.yview)
        scrollbar_seq.place(x=608, y=15, height=190)
        #On lie la scrollbar au texte et on définie notre séquence comme étant le texte
        text_seq.configure(yscrollcommand=scrollbar_seq.set)
        text_seq.insert("1.0", seq)
    return


def fragment(seq, window):
    """Fonction permettant de fractionner une séquence par fenêtre, si la taille de la fenêtre est correcte."""
    #Si la taille de la fenêtre est comprise entre 1 et la taille de la séquence, on créer un dictionnaire
    if window>0 and window<len(seq):
        dico={}
        #On parcourt notre séquence et on l'ajoute à notre dictionnaire par fragments de la taille de notre fenêtre
        i=0
        while i<=len(seq):
            if i!=0 and i%window==0:
                dico[i//window]=seq[i-window:i] #Chaque fragment est accessible dans le dictionnaire via un indice qui débute à 1
            i+=1
    return dico


def gc_skew(seq, window):
    """Fonction permettant de calculer le gc skew, et d'afficher les résultats sous forme d'un graphe."""
    #On fragmente la séquence dans un dictionnaire
    fragmented_seq = fragment(seq, window)
    #Si la taille de la fenêtre est comprise entre 1 et la taille de la séquence, on créer une figure et un subplot
    if window>0 and window<len(seq):
        figure = Figure(figsize=(5, 4), dpi=100)
        subplot = figure.add_subplot(111)
        subplot.set_title('GC SKEW') #On définit le titre de notre plot
        subplot.set_xlabel('Numéro fenêtre glissante (taille = '+str(window)+')') #On définit l'axe des abscisses de notre plot
        subplot.set_ylabel('(G-C)/(G+C)') #On définit l'axe des ordonnées de notre plot
        #On créer une liste pour stocker les points d'inversions et une liste des clés du dictionnaire avec les fragments
        inversions_gc=[]
        keys=list(fragmented_seq.keys())
        #On parcourt le dictionnaire et on fait le calcul du gc skew sur chaque fragment
        i=0
        while i<len(keys):
            #On compte le nombre de g et de c
            g=fragmented_seq[keys[i]].count('G')
            c=fragmented_seq[keys[i]].count('C')
            #Si on a le même nombre de g que de c, le calcul est nul
            if g==c:
                calcul=0
            #Sinon, on fait le calcul du gc skew
            else:
                calcul=(g-c)/(g+c)
            #Dans le dictionnaire, on remplace les fragments par leur valeur de gc skew
            fragmented_seq[keys[i]]=calcul
            #On trace les points en fonction des valeurs obtenues
            subplot.scatter(keys[i], fragmented_seq[keys[i]], c='red', s=10)
            if i!=0 and i<=len(keys):
                #Si il y a une différence de signe entre une valeur du dictionnaire et la précédente,
                if (fragmented_seq[keys[i]]>=0 and fragmented_seq[keys[i-1]]<0) or (fragmented_seq[keys[i]]<0 and fragmented_seq[keys[i-1]]>=0):
                    #on ajoute la dernière position de la fenêtre précédente et la première position de la fenêtre actuelle à la liste des inversions
                    inversions_gc.append(str(window*(keys[i-1]-1)+window)+"-"+str(window*(keys[i]-1)+1))
            i+=1
        values=list(fragmented_seq.values()) #Liste des valeurs du dictionnaire
        #On fait le plot avec les clés en abscisses et les valeurs de gc skew en ordonnées
        subplot.set_xticks(range(int(min(keys)), int(max(keys)) + 1))
        subplot.plot(keys, values, c='red')
        subplot.axhline(y=0, color='black', linestyle='--') #On trace une ligne au niveau du 0 des ordonnées pour bien voir les inversions
        #On place notre plot sur un canvas
        canvas = FigureCanvasTkAgg(figure, master=root)
        figure.tight_layout()
        canvas.draw()
        canvas_widget=canvas.get_tk_widget()
        canvas_widget.place(x=200,y=300)
        #On stocke notre liste d'inversion pour pouvoir l'exploiter sous forme de tableau ensuite
        #table.append(inversions_gc)
    return inversions_gc



def at_skew(seq, window):
    """Fonction permettant de calculer l'at skew, et d'afficher les résultats sous forme d'un graphe."""
    #On fragmente la séquence dans un dictionnaire
    fragmented_seq = fragment(seq, window)
    #Si la taille de la fenêtre est comprise entre 1 et la taille de la séquence, on créer une figure et un subplot
    if window>0 and window<len(seq):
        figure = Figure(figsize=(5, 4), dpi=100)
        subplot = figure.add_subplot(111)
        subplot.set_title('AT SKEW') #On définit le titre de notre plot
        subplot.set_xlabel('Numéro fenêtre glissante (taille = '+str(window)+')') #On définit l'axe des abscisses de notre plot
        subplot.set_ylabel('(A-T)/(A+T)') #On définit l'axe des ordonnées de notre plot
        #On créer une liste pour stocker les points d'inversions et une liste des clés du dictionnaire avec les fragments
        inversions_at=[]
        keys=list(fragmented_seq.keys())
        #On parcourt le dictionnaire et on fait le calcul du at skew sur chaque fragment
        i=0
        while i<len(keys):
            #On compte le nombre de a et de t
            a=fragmented_seq[keys[i]].count('A')
            t=fragmented_seq[keys[i]].count('T')
            #Si on a le même nombre de a que de t, le calcul est nul
            if a==t:
                calcul=0
            #Sinon, on fait le calcul du at skew
            else:
                calcul=(a-t)/(a+t)
            #Dans le dictionnaire, on remplace les fragments par leur valeur d'at skew
            fragmented_seq[keys[i]]=calcul
            #On trace les points en fonction des valeurs obtenues
            subplot.scatter(keys[i], fragmented_seq[keys[i]], c='red', s=10)
            if i!=0 and i<=len(keys):
                #Si il y a une différence de signe entre une valeur du dictionnaire et la précédente,
                if (fragmented_seq[keys[i]]>=0 and fragmented_seq[keys[i-1]]<0) or (fragmented_seq[keys[i]]<0 and fragmented_seq[keys[i-1]]>=0):
                    #on ajoute la dernière position de la fenêtre précédente et la première position de la fenêtre actuelle à la liste des inversions
                    inversions_at.append(str(window*(keys[i-1]-1)+window)+"-"+str(window*(keys[i]-1)+1))
            i+=1
        values=list(fragmented_seq.values()) #Liste des valeurs du dictionnaire
        #On fait le plot avec les clés en abscisses et les valeurs d'at skew en ordonnées
        subplot.set_xticks(range(int(min(keys)), int(max(keys)) + 1))
        subplot.plot(keys, values, c='red')
        subplot.axhline(y=0, color='black', linestyle='--') #On trace une ligne au niveau du 0 des ordonnées pour bien voir les inversions
        #On place notre plot sur un canvas
        canvas = FigureCanvasTkAgg(figure, master=root)
        figure.tight_layout()
        canvas.draw()
        canvas_widget=canvas.get_tk_widget()
        canvas_widget.place(x=800,y=300)
        #On stocke notre liste d'inversion pour pouvoir l'exploiter sous forme de tableau ensuite
        #table.append(inversions_at)
    return inversions_at


def dnaA_boxes(seq, pattern):
    """Fonction permettant de rechercher un motif dans une séquence."""
    list=[]
    start=0
    #Boucle infinie permettant de trouver un motif à partir d'un début que l'on augmente à chaque itération
    while True:
        index=seq.find(pattern, start)
        #Si on ne trouve pas le motif, on sort de la boucle
        if index == -1:
            break
        list.append(index) #On ajoute l'index à la liste
        start = index + 1
    #On trie la liste puis on la stocke pour pouvoir l'exploiter sous forme de tableau ensuite
    list.sort() 
    #table.append(list)
    return list


###TESTS###

def test_read_file():
    seq = "ATGCATGCATGCATGC"
    file_name = "test_sequence.txt"
    #On créer un fichier FASTA et on compare le résultat de notre fonction avec le résultat attendu
    with open(file_name, "w") as f:
        f.write(">Test Sequence\n")
        f.write(seq)
    result = read_file(file_name)
    expected = seq
    assert result == expected, f"Erreur lecture séquence." #Affichage d'une erreur si les résulats ne sont pas les mêmes
    print("✅ test_read_file OK")


def test_fragment():
    seq = "ATGCATGCATGCATGC"
    window = 4
    result = fragment(seq, window)
    #Vérifier si les résultats sont cohérents
    expected = {1: "ATGC", 2: "ATGC", 3: "ATGC", 4: "ATGC"}
    assert result == expected, f"Résultat attendu: {expected}, obtenu: {result}" #Affichage d'une erreur si les résulats ne sont pas les mêmes
    print("✅ test_fragment OK")


def test_gc_skew():
    seq = "GGGGCCCCGGGGCCCCATATATAT"
    window = 4
    result = gc_skew(seq, window)
    #Vérifier si les résultats sont cohérents
    assert isinstance(result, list), "Le résultat doit être une liste." #Affichage d'une erreur si le résultat n'est pas une liste
    expected = ['4-5', '8-9', '12-13', '16-17']
    assert result == expected, f"Résultat attendu: {expected}, obtenu: {result}" #Affichage d'une erreur si les résulats ne sont pas les mêmes
    print("✅ test_gc_skew OK")


def test_at_skew():
    seq = "AAAATTTTAAAATTTTGGGGCCCC"
    window = 4 
    result = at_skew(seq, window)
    # Vérifier si les résultats sont cohérents
    assert isinstance(result, list), "Le résultat doit être une liste." #Affichage d'une erreur si le résultat n'est pas une liste
    expected = ['4-5', '8-9', '12-13', '16-17']
    assert result == expected, f"Résultat attendu: {expected}, obtenu: {result}" #Affichage d'une erreur si les résulats ne sont pas les mêmes
    print("✅ test_at_skew OK")


def test_dnaA_boxes():
    pattern = "TTATCCACA"
    seq = "AAATTATCCACAGGGTTATCCACAXXXTTATCCACAYYY"
    result = dnaA_boxes(seq, pattern)
    # Vérifier si les résultats sont cohérents
    assert isinstance(result, list), "Le résultat doit être une liste." #Affichage d'une erreur si le résultat n'est pas une liste
    assert len(result) == 3, f"Il doit y avoir 3 occurrences, mais trouvé : {len(result)}" #Affichage d'une erreur si il n'y a pas trois indices dans la liste
    expected = [3, 15, 27]
    assert result == expected, f"Résultat attendu: {expected}, obtenu: {result}" #Affichage d'une erreur si les résulats ne sont pas les mêmes
    print("✅ test_dnaA_boxes OK")


###FONCTION MAIN###

def main():
    table=[]
    filename = entry_file.get() #On récupère le chemin du fichier dans l'entrée
    window = int(entry_window.get()) #On récupère la taille de la fenêtre dans l'entrée
    pattern=str(entry_box.get()) #On récupère la boîte DnaA dans l'entrée
    #On déroule nos fonctions
    seq=str(read_file(filename))
    window_check(seq, window)
    table.append(gc_skew(seq, window))
    table.append(at_skew(seq, window))
    table.append(dnaA_boxes(seq, pattern))
    #On créer un dataframe avec les listes contenant les positions des inversions gc, des inversions at, et des boîte DnaA
    titles=["Inversions GC", "Inversions AT", "dnaA boxes"]
    df=pd.DataFrame(table, index=titles)
    tree = ttk.Treeview(root)
    #Définition des colonnes du tableau
    tree["columns"] = ["Titre"] + list(df.columns)
    #On cache la première colonne "vide"
    tree["show"] = "headings" 
    #Création et configuration d’un style personnalisé pour le Treeview
    style = ttk.Style()
    style.configure("Treeview", rowheight=25) 
    # Définition de l’en-tête pour la colonne "Titre"
    tree.heading("Titre", text="")
    tree.column("Titre", width=75)
    #Pour chaque colonne du DataFrame, on définit son en-tête et sa largeur
    for col in df.columns:
        tree.heading(col, text=col)
        tree.column(col, width=50)
    #Remplissage du tableau : chaque ligne du DataFrame devient une ligne du Treeview
    for index, row in df.iterrows():
        tree.insert("", "end", values=[index] + list(row))
    tree.place(x=10, y=750, width=1485, height=110)
    return


###TKINTER###

root = tk.Tk() #Création de la racine principale
root.title("Recherche d'une origine de réplication bactérienne") #On définit le titre de notre interface
#On ajuste la taille de notre interface à la taille de l'écran
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")
#On définit les widgets de base de notre interface
label_file = tk.Label(root, text="Entrez le chemin du fichier :")
label_file.place(x=50,y=50)
entry_file = tk.Entry(root, width=50)
entry_file.place(x=230,y=50)
label_window = tk.Label(root, text="Entrez la taille de la fenêtre :")
label_window.place(x=50,y=90)
entry_window = tk.Entry(root, width=50)
entry_window.place(x=230,y=90)
label_box = tk.Label(root, text="Entrez la boîte DnaA :")
label_box.place(x=90, y=130)
entry_box = tk.Entry(root, width=50)
entry_box.place(x=230,y=130)
label_check = tk.Label(root, text="")
label_check.place(x=50,y=170)
button_submit = tk.Button(root, text="Submit", command=main)
button_submit.place(x=550,y=170)
button_clear = tk.Button(root, text="Clear", command=clear)
button_clear.place(x=625,y=170)
#On effectue les tests dès que la page Tkinter est lancée
test_read_file()
test_fragment()
test_gc_skew()
test_at_skew()
test_dnaA_boxes()
clear()
#On ferme l'interface graphique à la fin des interactions
root.mainloop()





